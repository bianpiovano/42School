/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bpiovano <bpiovano@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 14:45:04 by bpiovano          #+#    #+#             */
/*   Updated: 2024/11/12 16:43:25 by bpiovano         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	unsigned int	i;
	char			*res;

	res = malloc((ft_strlen(s) + 1) * sizeof(char));
	if (!res)
		return (NULL);
	i = 0;
	while (i < ft_strlen(s))
	{
		res[i] = (*f)(i, s[i]);
		i++;
	}
	res[i] = 0;
	return (res);
}
/*
 * Takes :
 * a string on which iterate (s)
 * the function to apply to each character (f)
 * Applies the function f to each character of the string s,
 * passing its index as the first argument and the character
 * itself as the second
 * A new string is created to collect the results
 * from the successive applications of f
 * Returns null if the allocation fails
 * Returns : string created from the successive applications of f
 */